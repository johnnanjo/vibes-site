@echo off
rem VIBES BILLIARDS DIGITAL LABO - open the scoreboard full screen when the PC starts
set "URL=https://vibesbilliards.com/pages/count/"
set "OPT=--kiosk --no-first-run --autoplay-policy=no-user-gesture-required"
set "C1=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
set "C2=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
set "C3=%LocalAppData%\Google\Chrome\Application\chrome.exe"
timeout /t 15 /nobreak >nul
if exist "%C1%" goto c1
if exist "%C2%" goto c2
if exist "%C3%" goto c3
start "" msedge %OPT% --edge-kiosk-type=fullscreen "%URL%"
goto end
:c1
start "" "%C1%" %OPT% "%URL%"
goto end
:c2
start "" "%C2%" %OPT% "%URL%"
goto end
:c3
start "" "%C3%" %OPT% "%URL%"
:end
